<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * @mixin \App\Models\Patient
 */
class PatientResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'age' => $this->age,
            'phone' => $this->phone,
            'mobile' => $this->mobile,
            'gender' => $this->gender,
            'file_number' => $this->file_number,
            'image' => $this->image,
            'files' => FileResource::collection($this->whenLoaded('files')),
            'symptoms' => PatientRecordResource::collection($this->whenLoaded('symptoms')),
            'diagnosis' => PatientRecordResource::collection($this->whenLoaded('diagnosis')),
            'created_at' => $this->created_at->format("Y-m-d H:i:s"),
        ];
    }
}
