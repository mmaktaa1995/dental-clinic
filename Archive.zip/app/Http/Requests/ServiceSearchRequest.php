<?php

namespace App\Http\Requests;

use App\Services\Search\Base\SearchRequest;

class ServiceSearchRequest extends SearchRequest
{
}
