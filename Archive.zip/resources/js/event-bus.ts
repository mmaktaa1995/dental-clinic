import { getCurrentInstance } from "vue"

export const EventBus = getCurrentInstance()
