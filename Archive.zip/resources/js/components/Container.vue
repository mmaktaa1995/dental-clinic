<template>
    <div class="px-4 pt-5 sm:p-6">
        <slot></slot>
    </div>
</template>
