<template>
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" :class="sizeClass">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
    </svg>
</template>

<script setup lang="ts">
import { useSizeClass } from "@/composables/sizable.js"

const { size } = defineProps<{
    size: number | string
}>()
const sizeClass = useSizeClass(size)
</script>
