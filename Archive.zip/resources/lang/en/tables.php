<?php

return [

    'admins'=>'Admins',
    'users'=>'Users',
    'contact_mails'=>'Contact Mails',
    'general'=>'General',
    'countries'=>'Countries',
    'states'=>'States',
    'cities'=>'Cities',
    'slider_items'=>'Slider Items',
    'learned_languages'=>'Learned Languages',
    'tags'=>'Tags',
    'religions'=>'Religions',
    'ideologies'=>'Ideologies',
    'races'=>'Races',
    'locations'=>'Locations',
    'civil_status'=>'Civil Status',
    'educational_situations'=>'Educational Situation',
    'political_situations'=>'Political Situation',
    'patients'=>'Patients',
    'services'=>'Services',
    'visits'=>'Visits',
    'expenses'=>'Expenses',
];