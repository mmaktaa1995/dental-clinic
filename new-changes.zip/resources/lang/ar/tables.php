<?php

return [

    'admins'=>'المدراء',
    'users'=>'المستخدمين',
    'patients'=>'المرضى',
    'services'=>'الخدمات',
    'visits'=>'الزيارات',
    'expenses'=>'المصاريف',
];