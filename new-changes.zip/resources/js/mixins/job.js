export default {
    methods: {
        /**
         * Returns the log color by the given display name.
         */
        jobColor(displayName) {
            return 'red';
        },
    },
};
